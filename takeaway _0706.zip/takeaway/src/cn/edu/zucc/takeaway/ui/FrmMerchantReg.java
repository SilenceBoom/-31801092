package cn.edu.zucc.takeaway.ui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import cn.edu.zucc.takeaway.TakeAwayUtil;
import cn.edu.zucc.takeaway.model.BeanMerchant;
import cn.edu.zucc.takeaway.model.BeanUser;
import cn.edu.zucc.takeaway.util.BaseException;

public class FrmMerchantReg extends JDialog implements ActionListener {
	private JPanel toolBar = new JPanel();
	private JPanel workPane = new JPanel();
	private Button btnOk = new Button("ע��");
	private Button btnCancel = new Button("ȡ��");
	private JComboBox jcb=null;
	private JLabel labelName = new JLabel("�̼����ƣ�");
	private JLabel labelStar = new JLabel("�̼��Ǽ���                     ");
	private JLabel labelRjxf = new JLabel("�˾����ѣ�");
	private JLabel labelCount= new JLabel("��  ��  ����");
	private JLabel labelkong=new JLabel("��                                ");
	private JTextField edtName = new JTextField(20);
	private JTextField edtRjxf = new JTextField(20);
	private JTextField edtCount = new JTextField(20);

	public FrmMerchantReg(Frame f, String s, boolean b) {
		super(f,s,b);
	    String star[]= {"  1 ","  2  ","  3  ","  4  ","  5  "};
	    this.jcb=new JComboBox(star);
	    jcb.setMaximumRowCount(5);
		toolBar.setLayout(new FlowLayout(FlowLayout.RIGHT));
		toolBar.add(this.btnOk);
		toolBar.add(btnCancel);
		this.getContentPane().add(toolBar, BorderLayout.SOUTH);
		workPane.add(labelName);
		workPane.add(edtName);
		workPane.add(labelStar);
		workPane.add(jcb);
		workPane.add(labelkong);
		workPane.add(labelRjxf);
		workPane.add(edtRjxf);
		workPane.add(labelCount);
		workPane.add(edtCount);
		this.getContentPane().add(workPane, BorderLayout.CENTER);
		this.setSize(320, 200);
		double width = Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		double height = Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		this.setLocation((int) (width - this.getWidth())/2,
				(int) (height - this.getHeight())/2 );

		this.validate();
		this.btnCancel.addActionListener(this);
		this.btnOk.addActionListener(this);

		
		
	}
	public void actionPerformed(ActionEvent e) {
	    if(e.getSource()==this.btnCancel) {
	    	this.setVisible(false);
	    }   	
		else if(e.getSource()==this.btnOk) {
			String name=this.edtName.getText();
			double rjxf=Double.parseDouble(this.edtRjxf.getText());
			int count=Integer.parseInt(this.edtCount.getText());
			int star=0;
			switch(jcb.getSelectedIndex()) {
			case 0:star=1;break;
			case 1:star=2;break;
			case 2:star=3;break;
			case 3:star=4;break;
			case 4:star=5;break;	
			}
			try {
				BeanMerchant merchant=TakeAwayUtil.merchantManager.reg(name,star,rjxf, count);
				this.setVisible(false);
			} catch (BaseException e1) {
				JOptionPane.showMessageDialog(null, e1.getMessage(),"����",JOptionPane.ERROR_MESSAGE);
				return;
			}
		}
		
	}

}
