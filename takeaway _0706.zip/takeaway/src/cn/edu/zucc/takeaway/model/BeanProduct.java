package cn.edu.zucc.takeaway.model;

public class BeanProduct {
	private int productid;
	private int sortid;
	private int orderid;
	private int addressid;
	private int productcount;
	private double productprice;
	private double productcoupon;
	public int getProductid() {
		return productid;
	}
	public void setProductid(int productid) {
		this.productid = productid;
	}
	public int getSortid() {
		return sortid;
	}
	public void setSortid(int sortid) {
		this.sortid = sortid;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getAddressid() {
		return addressid;
	}
	public void setAddressid(int addressid) {
		this.addressid = addressid;
	}
	public int getProductcount() {
		return productcount;
	}
	public void setProductcount(int productcount) {
		this.productcount = productcount;
	}
	public double getProductprice() {
		return productprice;
	}
	public void setProductprice(double productprice) {
		this.productprice = productprice;
	}
	public double getProductcoupon() {
		return productcoupon;
	}
	public void setProductcoupon(double productcoupon) {
		this.productcoupon = productcoupon;
	}
	

}
