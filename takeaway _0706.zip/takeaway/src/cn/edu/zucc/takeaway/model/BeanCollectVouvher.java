package cn.edu.zucc.takeaway.model;

public class BeanCollectVouvher {
	private int userid;
	private int merchantid;
	private int requirecount;
	private int ordercount;
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public int getMerchantid() {
		return merchantid;
	}
	public void setMerchantid(int merchantid) {
		this.merchantid = merchantid;
	}
	public int getRequirecount() {
		return requirecount;
	}
	public void setRequirecount(int requirecount) {
		this.requirecount = requirecount;
	}
	public int getOrdercount() {
		return ordercount;
	}
	public void setOrdercount(int ordercount) {
		this.ordercount = ordercount;
	}
	
 
}
