package cn.edu.zucc.takeaway.model;

public class BeanFullReduce {
	private int fullreduid;
	private int merchantid;
	private double fullreduprice;
	private double fullcoupon;
	private int isadd;
	public int getFullreduid() {
		return fullreduid;
	}
	public void setFullreduid(int fullreduid) {
		this.fullreduid = fullreduid;
	}
	public int getMerchantid() {
		return merchantid;
	}
	public void setMerchantid(int merchantid) {
		this.merchantid = merchantid;
	}
	public double getFullreduprice() {
		return fullreduprice;
	}
	public void setFullreduprice(double fullreduprice) {
		this.fullreduprice = fullreduprice;
	}
	public double getFullcoupon() {
		return fullcoupon;
	}
	public void setFullcoupon(double fullcoupon) {
		this.fullcoupon = fullcoupon;
	}
	public int getIsadd() {
		return isadd;
	}
	public void setIsadd(int isadd) {
		this.isadd = isadd;
	}
	

}
