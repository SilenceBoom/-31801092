package cn.edu.zucc.takeaway.comtrol;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cn.edu.zucc.takeaway.itf.IMerchantManager;
import cn.edu.zucc.takeaway.model.*;
import cn.edu.zucc.takeaway.util.BaseException;
import cn.edu.zucc.takeaway.util.BusinessException;
import cn.edu.zucc.takeaway.util.DBUtil;
import cn.edu.zucc.takeaway.util.DbException;

public class MerchantManager implements IMerchantManager{
	public BeanMerchant reg(String name,int star,double rjxf,int count)throws BaseException{
		BeanMerchant merchant=new BeanMerchant();
		Connection conn=null;
		try {
			int id=0;
			conn=DBUtil.getConnection();
			String sql="select count(*) from merchant";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				id=rs.getInt(1)+1;
			}
		    sql="select * from merchant where merchantName='"+name+"'";
		    pst=conn.prepareStatement(sql);
		    rs=pst.executeQuery();
		    if(rs.next()) throw new BaseException("�̼�������ע��");
		    sql="insert into merchant(merchantId,merchantName,merchantLevel,avgConsume,sumCount) values(?,?,?,?,?)";
		    pst=conn.prepareStatement(sql);
		    pst.setInt(1, id);
		    pst.setString(2,name);
		    pst.setInt(3, star);
		    pst.setDouble(4, rjxf);
		    pst.setInt(5, count);
		    pst.execute();
		    pst.close();
		    return merchant;
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public List<BeanMerchant> loadall()throws BaseException{
		List<BeanMerchant> result=new ArrayList<BeanMerchant>();
		Connection conn=null;
		try {
			
			conn=DBUtil.getConnection();
			String sql="select * from merchant";
			java.sql.Statement st=conn.createStatement();
			java.sql.ResultSet rs=st.executeQuery(sql);
			while(rs.next()) {
				 BeanMerchant p=new BeanMerchant();
				 p.setMerchantid(rs.getInt(1));
				 p.setMerchantname(rs.getString(2));
				 p.setMerchantlevel(rs.getInt(3));
				 p.setAvgConsume(rs.getDouble(4));
				 p.setSumcount(rs.getInt(5));
		         result.add(p);
			}
		    rs.close();
		    st.close();
		    return result;
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public BeanMerchant search(String name)throws BaseException{
		BeanMerchant result=new BeanMerchant();
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="select * from merchant where merchantName=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, name);
			java.sql.ResultSet rs=pst.executeQuery();
			while(rs.next()) {
				result.setMerchantid(rs.getInt(1));
				result.setMerchantname(rs.getString(2));
				result.setMerchantlevel(rs.getInt(3));
				result.setAvgConsume(rs.getDouble(4));
				result.setSumcount(rs.getInt(5));
			}
			rs.close();
			pst.close();
			return result;
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
	public void delete(BeanMerchant merchant) throws BaseException{
		Connection conn=null;
		try {
			conn=DBUtil.getConnection();
			String sql="delete from merchant where merchantName=?";
			java.sql.PreparedStatement pst=conn.prepareStatement(sql);
			pst.setString(1, merchant.getMerchantname());
			pst.execute();
			pst.close();
		}catch (SQLException e) {
			e.printStackTrace();
			throw new DbException(e);
		}
		finally{
			if(conn!=null)
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
	}
}
